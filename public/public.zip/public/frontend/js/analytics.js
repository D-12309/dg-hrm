

$(document).ready(function() {
    function submit(){
          $('#form').submit();
      }
});