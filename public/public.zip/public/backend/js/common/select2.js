"use strict";

$('select').select2({
    placeholder: 'Choose one',
})

$('.select2').select2();

const progressValue = (val) => {
    $('#progress_percentage').html(val + '%');
}