$('table').dataTable({
    searching: false,
    paging: false,
    info: false
});