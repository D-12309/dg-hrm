"use strict";
CKEDITOR.replace("content");
CKEDITOR.editorConfig = function(config) {
    config.toolbar = [
        ["TextColor", "BGColor"]
    ];
};
