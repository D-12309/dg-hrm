"use strict";
CKEDITOR.replace('description');
CKEDITOR.editorConfig = function (config) {
    config.toolbar = [['TextColor', 'BGColor']]
};