"use strict";

CKEDITOR.replace( 'en' );
CKEDITOR.replace( 'bn' );
CKEDITOR.editorConfig = function( config ) {
    config.toolbar = [['TextColor', 'BGColor']]
};
