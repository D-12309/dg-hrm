"use strict";

CKEDITOR.replace('message');
CKEDITOR.editorConfig = function (config) {
    config.toolbar = [['TextColor', 'BGColor']]
};